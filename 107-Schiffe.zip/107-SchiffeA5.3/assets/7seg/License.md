This files are unter creative commons license and taken from the wiki commons project.
