/**
 * Schiffe versenken - Das Erstispiel
 * @author leondietrich
 *
 */
package de.uniluebeck.itm.schiffeversenken.main;