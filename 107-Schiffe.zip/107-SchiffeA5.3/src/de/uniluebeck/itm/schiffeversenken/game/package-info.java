/**
 * This package contains classes that are directly relevant to the game logic.
 * @author leondietrich
 *
 */
package de.uniluebeck.itm.schiffeversenken.game;