/**
 * This package contains home made GUI components. Yes - There are premade ones
 * with every GUI toolkit but it may be interesting for students to have a look
 * at these as they don't contain multiple thousand lines of code for mostly not
 * required features.
 * 
 * @author leondietrich
 *
 */
package de.uniluebeck.itm.schiffeversenken.engine.uicomponents;