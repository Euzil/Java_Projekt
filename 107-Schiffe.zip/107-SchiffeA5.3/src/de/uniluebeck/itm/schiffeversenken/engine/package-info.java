/**
 * This package contains all the classes that should be hidden from the user
 */
package de.uniluebeck.itm.schiffeversenken.engine;