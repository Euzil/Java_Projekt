/**
 * This package contains scenes that are not really part of the game.
 * @author leondietrich
 *
 */
package de.uniluebeck.itm.schiffeversenken.engine.utilityscenes;