# jp2-schiffe-versenken
An dieser Stelle eine kleine Übersicht über das Template:

 * Im Ordner assets befinden sich Texturen, die Sie für das Spiel benötigen. Sorgen Sie dafür, dass dieser Ordner im Ausführungsverzeichniss Ihres Spiels verfügbar ist.
 * Im Ordner src befinden sich bereits für Sie vorbereitete Java Sourcefiles. Diese sind unterteilt in ein engine- und ein game-Package. Verschaffen Sie sich einen
   grundlegenden Überblick über beide Packete.

Weitere Anweisungen entnehmen Sie bitte Aufgabenblatt 0.
